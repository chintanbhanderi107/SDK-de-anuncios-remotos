package com.custom.ads.sdk.utils

class Utils {
    companion object {
        var firebaseConfigKey: String = "test_ads"
        const val AD_UNIT: String = "ad_unit"
        const val CROSS_PROMOTION: String = "cross_promotion"
        const val CROSS_PROMOTION_INTERSTITIAL: String = "cross_promotion_interstitial"
    }
}