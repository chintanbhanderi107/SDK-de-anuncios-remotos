package com.custom.ads.sdk.utils

enum class ConfigType {
    REMOTE_CONFIG,
    FIRESTORE_DATABASE
}