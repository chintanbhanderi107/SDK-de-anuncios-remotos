package com.custom.ads.sdk.interfaces

interface AppOpenAdShowedListener {
    fun onCompleted()
}