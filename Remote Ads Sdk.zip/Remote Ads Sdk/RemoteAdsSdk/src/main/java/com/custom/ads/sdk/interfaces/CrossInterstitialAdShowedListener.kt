package com.custom.ads.sdk.interfaces

interface CrossInterstitialAdShowedListener {
    fun onCompleted()
}