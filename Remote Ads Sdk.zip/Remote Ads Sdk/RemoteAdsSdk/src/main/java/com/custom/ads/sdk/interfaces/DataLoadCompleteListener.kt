package com.custom.ads.sdk.interfaces

interface DataLoadCompleteListener {
    fun onDataLoaded()
    fun onDataLoadFailed()
}
