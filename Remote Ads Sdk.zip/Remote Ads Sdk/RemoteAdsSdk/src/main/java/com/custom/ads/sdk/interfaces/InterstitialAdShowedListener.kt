package com.custom.ads.sdk.interfaces

interface InterstitialAdShowedListener {
    fun onCompleted()
}